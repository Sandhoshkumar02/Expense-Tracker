package com.sandy.expensetracker.expensetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
